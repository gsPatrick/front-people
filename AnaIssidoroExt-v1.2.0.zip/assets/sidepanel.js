import{R as e,j as t,a as o,P as r}from"./index.js";import"./api.service.js";e.createRoot(document.getElementById("root")).render(t.jsx(o.StrictMode,{children:t.jsx(r,{})}));
